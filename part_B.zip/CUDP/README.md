# CUDP: code for the dissertation

**Correlation-Aware and User-Centric Differential Privacy: Feature-Level Budget Allocation and Preference-Based
Budget Selection in Central and Federated Settings**

Wenjun Yang, University of Washington Tacoma, 2026.

This repository is a public snapshot of the code, configurations, and result summaries behind the experiments of
the dissertation, prepared so that the committee can check how each table and figure was produced. It does not
contain the development history (see "Development records" below for the commit hashes cited in the thesis).

| Chapter | Folder | Contents |
|---|---|---|
| 4 (MIC-DP) | `ch4_micdp/` | Mechanism, experiment, public-data baselines, Draft 3 follow-up runs, stored results |
| 5 (LDP-MIC) | `ch5_ldpmic/` | Added separately |
| 6 (PrefSelect) | `ch6_prefselect/` | TOPSIS selection, decision matrices from the Chapter 4 curves, all Chapter 6 tables and figures |
| 7 (PrivAgent) | `ch7_privagent/` | Pre-registered simulation with simulated users, exploratory misspecification run, stored results |
| 8 (user study) | `ch8_user_study/` | Added separately |
| 9 (conclusion) | none | No code |
| | `thesis_figures/` | Empty; reserved for the final figure files of the thesis |

## Setup

Python 3.13 (all runs used 3.13.18), CPU only.

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

The Chapter 4 raw datasets are public but are not redistributed here: `cd ch4_micdp && python fetch_data.py`
downloads them and checks their SHA-256 (see `ch4_micdp/data/raw/README.md`). The Chapter 6 and Chapter 7 checks need
no download.

## One check per chapter

Each command was run in a fresh virtual environment with `requirements.txt` before this snapshot was published.

| Chapter | Command (run inside the folder) | Time | What it checks |
|---|---|---|---|
| 4 | `python check.py` | ~10 s | 95 unit tests (106 once `fetch_data.py` has been run); recomputes the 258 tests of families F1 to F5 and F1 (linear model) from the stored per-trial results and compares every outcome with `results/ch4/stats.csv` |
| 6 | `python -m pytest -q && python make_ch6.py` | ~5 s | 12 unit tests; rebuilds every Chapter 6 table and both figures and checks them against the thesis values |
| 7 | `python -m src.run --smoke` | ~5 s | 25 unit tests, static checks of Table 7.3, a 2-replication run with all sanity checks |
| 7 (reproduction) | `python -m src.misspec` | ~2 min | Re-simulates the 20,000 users of the pre-registered primary population and checks that every estimated weight and every selected budget equals the stored main run |

Full runs: Chapter 4 `python -m src.run && python -m src.report` (about 2.5 hours on 2 CPUs; then
`python -m src.public && python -m src.public_report` and `python -m src.draft3 && python -m src.draft3_report`, about
45 and 60 minutes); Chapter 7 `python -m src.run && python -m src.report` (a few minutes), then
`python -m src.misspec && python -m src.misspec_report`.

## Where each table and figure comes from

Paths are relative to the chapter folder. "Stored" means the file is in the repository as produced by the run.

### Chapter 4 (MIC-DP), `ch4_micdp/`

| Thesis item | Produced by | Stored output |
|---|---|---|
| Table 4.x Datasets (`tab:ch4:datasets`) | `src/run.py` | `results/ch4/datasets.csv` |
| Table Score noise (`tab:ch4:scorenoise`) | `src/run.py` (sanity check 6) and `scores_raw.csv` (std of FG-MIC) | `results/ch4/sanity.log`, `results/ch4/scores_raw.csv` |
| Tables Utility on Adult / CDC-Diabetes (`tab:ch4:main_adult`, `tab:ch4:main_cdc`) | `src/report.py` | `results/ch4/tab_main_adult.tex`, `tab_main_cdc_diabetes.tex` |
| Appendix utility tables, primary and linear model (`tab:ch4:main_*`, `tab:ch4:sec_*`) | `src/report.py` | `results/ch4/tab_main_*.tex`, `tab_secondary_*.tex` |
| Table Significant comparisons per family (`tab:ch4:families`) and the hypothesis outcomes | `src/stats.py`, `src/report.py` | `results/ch4/stats.csv`, `summary.md` |
| Table Noise-aware against direct prediction (`tab:ch4:noiseaware`) | `src/draft3.py`, `src/draft3_report.py` (Part B) | `results/ch4/draft3/tab_b_noiseaware.tex`, `stats_draft3.csv` |
| Per-trial ROC-AUC, thresholds, 95% intervals, F1 linear model (text of 4.7, Draft 3 Part A) | `src/draft3_report.py` | `results/ch4/draft3/tab_a1_trials.tex` to `tab_a4_f1.tex`, `auc_trials_ch4.pdf`, `summary.md` |
| Attribute-sampling baseline Random-k (text, family F9) | `src/draft3.py`, `src/draft3_report.py` (Part D) | `results/ch4/draft3/tab_d_*.tex` |
| Table Public-data baselines (`tab:ch4:public`) and Figure (`fig:ch4:public`) | `src/public.py`, `src/public_report.py` | `results/ch4/public/tab_public_adult.tex`, `tab_public_cdc_diabetes.tex`, `public_ch4.pdf` |
| Repaired fine-tuning (text) | `src/draft3.py`, `src/draft3_report.py` (Part C) | `results/ch4/draft3/tab_c_ft_*.tex`, `diagnostic_ft_clip.csv` (from `diagnostics/draft3_ft_clip.py`) |
| Table Diagnostic of the fine-tuned models (`tab:ch4:ftdiag`) | `diagnostics/ft_leaf_values.py` | `results/ch4/public/diagnostic_ft.csv` |
| Table Demographic override (`tab:ch4:override`) | `src/report.py` | `results/ch4/tab_override.tex` |
| Figure Budget shares on Adult (`fig:ch4:weights_adult`) | `src/report.py` | `results/ch4/weights_adult.pdf` |
| Appendix tables distortion, ablation, synthetic, alpha, rho | `src/report.py` | `results/ch4/tab_distortion.tex`, `tab_ablation.tex`, `tab_synthetic.tex`, `tab_alpha.tex`, `tab_rho.tex` |
| Appendix figures alpha, rho, dual_*, synthetic_dose | `src/report.py` | `results/ch4/alpha.pdf`, `rho.pdf`, `dual_*.pdf`, `synthetic_dose.pdf` |
| Figure Paired differences to Uniform (`fig:ch4:paired`) | not in this snapshot (drawn while writing from `results/ch4/raw_trials.parquet`) | |
| Figure Pre-specified comparisons (`fig:ch4:heatmap`) | not in this snapshot (drawn while writing from `results/ch4/stats.csv`) | |
| Table Learnability check (`tab:ch4:learnability`) | values from `results/ch4/raw_trials.parquet` (non-private and best private MAE) and the training-mean predictor computed with `src/data.py`; no separate script | |

### Chapter 5 (LDP-MIC), `ch5_ldpmic/`

Added separately.

### Chapter 6 (PrefSelect), `ch6_prefselect/`

All items are produced by `make_ch6.py` from the Chapter 4 curves (`inputs/ch6_inputs.csv`); outputs in `results/`.

| Thesis item | Stored output |
|---|---|
| Decision matrices (`tab:ch6:matrix`) | `tab_matrix.csv` |
| Closeness coefficients of the profiles (`tab:ch6:profiles`, appendix `tab:ch6:profiles_reg`) | `tab_profiles.csv` |
| Fixed budgets against the selection (`tab:ch6:defaults`) | `tab_defaults.csv` |
| Selection with fixed ideals (`tab:ch6:absolute`) | `tab_absolute.csv` |
| Selection frequency over the simplex (`tab:ch6:freq`) | `tab_freq.csv` |
| Selected budget by privacy share (`tab:ch6:switch`) | `tab_switch.csv` |
| Figures trade-off and selection (`fig:ch6:tradeoff`, `fig:ch6:selection`) | `tradeoff_ch6.pdf`, `selection_ch6.pdf` |

### Chapter 7 (PrivAgent), `ch7_privagent/`

The stored tables of the pre-registered run (`results/ch7/tables/`) use the names of the pre-registration:
PrivAgent-6 = Vote-6, PrivAgent-6-Bayes = Bayes-6, PrivAgent-LPLA = Vote-LPLA, PrivAgent-LPLA-Bayes = PrivAgent.

| Thesis item | Produced by | Stored output |
|---|---|---|
| Table Selected budget for the profiles and the default (`tab:ch7:decision`) | `src/run.py` (static check of Table 7.3) | `results/ch7/sanity.log` |
| Table Pre-registered hypotheses (`tab:ch7:hypotheses`) | `src/stats.py`, `src/report.py` | `results/ch7/stats.csv`, `hypotheses_outcomes.json` |
| Table Weight metrics (`tab:ch7:weights`) | `src/report.py` | `results/ch7/tables/tab_weight_metrics.tex` |
| Table Budget agreement and closeness loss (`tab:ch7:budget`) | `src/report.py` | `results/ch7/tables/tab_budget_agreement.tex` |
| Figure Budget agreement (`fig:ch7:budget`) | `src/misspec_report.py` (current names) | `results/ch7/draft3/budget_agreement_ch7.pdf` |
| Table Anchoring strength (`tab:ch7:anchor`) | `src/report.py` | `results/ch7/tables/tab_anchor.tex` |
| Table and Figure Rounds (`tab:ch7:rounds`, `fig:ch7:rounds`) | `src/report.py`; figure `src/misspec_report.py` | `results/ch7/tables/tab_rounds.tex`, `results/ch7/draft3/rounds_ch7.pdf` |
| Table Profile populations (`tab:ch7:profiles`) | `src/report.py` | `results/ch7/tables/tab_profiles.tex` |
| Table and Figure User temperature (`tab:ch7:tau`, `fig:ch7:tau`) | `src/report.py`; figure `src/misspec_report.py` | `results/ch7/tables/tab_tau.tex`, `results/ch7/draft3/tau_ch7.pdf` |
| Table Users who break the response model (`tab:ch7:misspec`, exploratory) | `src/misspec.py`, `src/misspec_report.py` | `results/ch7/draft3/tab_misspec.tex`, `misspec_runs.csv`, `misspec_ch7.pdf`, `summary.md` |

### Chapter 8 (user study), `ch8_user_study/`

Added separately.

## Development records

The development repositories are private. Both were restored from archived snapshots after the compute
environment was reset, so the earliest history (including the Chapter 7 pre-registration commit) is recorded in the
files rather than in git.

| Chapter | Commit | Date | Content |
|---|---|---|---|
| 4 | `52748a9` | 2026-11-07 | Repository of the main run restored from the archived snapshot; a re-run of one trial reproduced the stored results to 1e-9 |
| 4 | `a11f76a` | 2026-11-07 | Public-data baselines: configuration, reporting rules, and code, before the run |
| 4 | `171f329` | 2026-11-07 | Public-data baselines: outputs |
| 4 | `8b2e018` | 2026-11-12 | Draft 3 follow-up runs: configuration and notes for Parts A to D, before any part ran |
| 4 | `6209f42` | 2026-11-12 | Draft 3: code and tests; Part C prediction amended before the main run |
| 4 | `b947f56` | 2026-11-12 | Draft 3: outputs |
| 7 | `7bffabb` | 2026-10-26 | Pre-registration of the simulation (hypotheses, configuration, code); recorded in `ch7_privagent/results/ch7/preregistration.txt` |
| 7 | `dc16b0e` | 2026-11-12 | Repository restored from the archived snapshot of the pre-registered run |
| 7 | `4002e0e` | 2026-11-12 | Misspecification run: settings, before the run |
| 7 | `61af0cd` | 2026-11-12 | Misspecification run: code and tests, before the run |
| 7 | `4c1fe14` | 2026-11-12 | Misspecification run: outputs and regenerated figures |

The deviations of each run from its plan are listed in the `summary.md` of its results folder and in
`ch4_micdp/draft3_notes.md`.

## Not included

- Raw datasets of Chapter 4 (public; downloaded by `ch4_micdp/fetch_data.py`, pinned by SHA-256).
- Raw progress logs of the runs (`run.log`), per-trial caches, and smoke-run outputs. The sanity-check logs are
  included.
- The development git history.
- The first run of the original MIC-DP design (v1), which the thesis describes but does not report.

## License

MIT (see `LICENSE`). To cite, see `CITATION.cff`.
