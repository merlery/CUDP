# Chapter 7 (PrivAgent) simulation: summary

All numbers are produced by `python -m src.run && python -m src.report` from the committed configuration and are reported as they came out. No human participants are involved: all users are simulated. The simulated users answer according to fixed true weights with logistic response noise; they have no anchoring in the dialogue, no present bias and no context-dependence. The anchored-slider baseline uses an assumed anchoring model (Section 3 of the specification).

## Pre-registration

Pre-registration commit: 7bffabb6dc67fb8829e0b8279c1d2e02e6eda1b0
Date: 2026-10-26 14:44:30 -0700
Committed: hypotheses.md (H1-H5 with decision rules), config.yaml (all settings), src/ (simulation, statistics with the decision rules, report) and tests/. Before the commit only the smoke run (2 replications, 100 users) was executed, to check that the code runs; no setting was chosen from it.

## Sanity checks

```
PASS unit tests (23 passed in 0.94s)
PASS expert and uniform defaults select the same eps* (adult, linear): 1 and 1
PASS expert and uniform defaults select the same eps* (adult, exponential): 0.1 and 0.1
PASS expert and uniform defaults select the same eps* (cdc, linear): 1 and 1
PASS expert and uniform defaults select the same eps* (cdc, exponential): 0.3 and 0.3
PASS Table 7.3 (adult, linear): profiles [1.0, 5.0, 1.0, 1.0] (want [1, 5, 1, 1]), default 1 (want 1)
PASS Table 7.3 (adult, exponential): profiles [0.1, 10.0, 0.1, 0.1] (want [0.1, 10, 0.1, 0.1]), default 0.1 (want 0.1)
PASS Table 7.3 (cdc, linear): profiles [1.0, 5.0, 1.0, 1.0] (want [1, 5, 1, 1]), default 1 (want 1)
PASS Table 7.3 (cdc, exponential): profiles [0.1, 10.0, 0.3, 0.3] (want [0.1, 10, 0.3, 0.3]), default 0.3 (want 0.3)
PASS Oracle (adult, exponential): agreement 1.0000, max |closeness loss| 0.00e+00, users 40000
PASS Oracle (adult, linear): agreement 1.0000, max |closeness loss| 0.00e+00, users 40000
PASS Oracle (cdc, exponential): agreement 1.0000, max |closeness loss| 0.00e+00, users 40000
PASS Oracle (cdc, linear): agreement 1.0000, max |closeness loss| 0.00e+00, users 40000
PASS expert and uniform defaults give the same eps* for every user and setting (160000 cases)
PASS tau = 1e-06, LP-LA prompts: privacy share on the wrong side of 0.5 for 0 (vote) and 0 (Bayes) of 18041 users with |pi - 0.5| > 0.05
INFO repair rate (PrivAgent-6, uniform population) by tau: 0.05: 0.0009, 0.1: 0.0036, 0.2: 0.0125, 0.4: 0.0232
INFO share of undefined selections (main analysis, all populations and settings): expert: 0.0000, lpla: 0.0000, lpla_bayes: 0.0000, oracle: 0.0000, pa6: 0.0000, pa6_bayes: 0.0000, slider: 0.0000, uniform_default: 0.0000
```

## Hypotheses

Primary population (uniform, 20,000 users), primary tau = 0.1, lambda = 0.4. Pooled means with 95% cluster-bootstrap intervals over replications; Holm within each family; a test counts if Holm-adjusted p < 0.05 and the pooled difference A - B has the stated sign. n_a_only / n_b_only: users for whom only A (only B) agrees (McNemar) or A > B (A < B) (Wilcoxon).

### H1: FAIL (0 of 2 tests in the stated direction)

| test | setting | A | B | metric | mean_A | mean_B | diff_A_minus_B | n_a_only | n_b_only | p_raw | p_holm | stated | counts |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| McNemar | adult/linear | PrivAgent-6 | Expert default | agreement | 0.326 [0.319, 0.332] | 0.410 [0.404, 0.417] | -0.085 [-0.095, -0.074] | 4264 | 5959 | 5.27e-63 | 1.05e-62 | greater | False |
| McNemar | cdc/linear | PrivAgent-6 | Expert default | agreement | 0.319 [0.313, 0.326] | 0.382 [0.375, 0.388] | -0.062 [-0.071, -0.052] | 4295 | 5538 | 5.45e-36 | 5.45e-36 | greater | False |

### H2: FAIL (0 of 2 tests in the stated direction)

| test | setting | A | B | metric | mean_A | mean_B | diff_A_minus_B | n_a_only | n_b_only | p_raw | p_holm | stated | counts |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| McNemar | adult/linear | PrivAgent-LPLA | PrivAgent-6 | agreement | 0.175 [0.169, 0.181] | 0.326 [0.319, 0.332] | -0.150 [-0.158, -0.142] | 1796 | 4801 | 1.99e-299 | 3.98e-299 | greater | False |
| McNemar | cdc/linear | PrivAgent-LPLA | PrivAgent-6 | agreement | 0.170 [0.163, 0.176] | 0.319 [0.313, 0.326] | -0.149 [-0.156, -0.142] | 1842 | 4829 | 1.28e-292 | 1.28e-292 | greater | False |

### H3: PASS (1 of 1 tests in the stated direction)

| test | setting | A | B | metric | mean_A | mean_B | diff_A_minus_B | n_a_only | n_b_only | p_raw | p_holm | stated | counts |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Wilcoxon | - | PrivAgent-6-Bayes | PrivAgent-6 | share_error | 0.126 [0.124, 0.127] | 0.212 [0.209, 0.215] | -0.086 [-0.088, -0.083] | 6302 | 13698 | 0 | 0 | less | True |

### H4: FAIL (0 of 2 tests in the stated direction)

| test | setting | A | B | metric | mean_A | mean_B | diff_A_minus_B | n_a_only | n_b_only | p_raw | p_holm | stated | counts |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| McNemar | adult/linear | PrivAgent-6 | Anchored slider | agreement | 0.326 [0.319, 0.332] | 0.773 [0.766, 0.780] | -0.447 [-0.456, -0.437] | 1671 | 10611 | 0 | 0 | greater | False |
| McNemar | cdc/linear | PrivAgent-6 | Anchored slider | agreement | 0.319 [0.313, 0.326] | 0.725 [0.720, 0.731] | -0.406 [-0.414, -0.396] | 1759 | 9873 | 0 | 0 | greater | False |

This result depends on the assumed anchoring model (anchor (1/3, 1/3, 1/3), strength lambda = 0.4, Gaussian report noise sd 0.1); see the anchoring sensitivity below.

### H5: FAIL (0 of 1 tests in the stated direction)

| test | setting | A | B | metric | mean_A | mean_B | diff_A_minus_B | n_a_only | n_b_only | p_raw | p_holm | stated | counts |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Wilcoxon | - | PrivAgent-6 | Expert default | cosine | 0.930 [0.929, 0.931] | 0.803 [0.801, 0.805] | 0.127 [0.125, 0.129] | 15121 | 4879 | 0 | 0 | less | False |

## Weight metrics (uniform population)

| method | cosine | L1 | privacy_share_error | prompts |
|---|---|---|---|---|
| Oracle | 1.000 [1.000, 1.000] | 0.000 [0.000, 0.000] | 0.000 [0.000, 0.000] | 0.000 |
| PrivAgent-6 | 0.930 [0.929, 0.931] | 0.425 [0.422, 0.429] | 0.212 [0.209, 0.215] | 6.004 |
| PrivAgent-6-Bayes | 0.961 [0.961, 0.962] | 0.285 [0.283, 0.287] | 0.126 [0.124, 0.127] | 6.004 |
| PrivAgent-LPLA | 0.850 [0.848, 0.852] | 0.577 [0.573, 0.582] | 0.228 [0.226, 0.230] | 6.000 |
| PrivAgent-LPLA-Bayes | 0.908 [0.907, 0.909] | 0.427 [0.424, 0.430] | 0.113 [0.112, 0.115] | 6.000 |
| Expert default | 0.803 [0.801, 0.805] | 0.630 [0.626, 0.633] | 0.251 [0.249, 0.253] | 0.000 |
| Uniform default | 0.834 [0.833, 0.835] | 0.595 [0.592, 0.598] | 0.251 [0.249, 0.253] | 0.000 |
| Anchored slider | 0.972 [0.972, 0.972] | 0.260 [0.258, 0.262] | 0.116 [0.115, 0.117] | 0.000 |

## Budget agreement and closeness loss (uniform population)

| method | Adult, linear agreement | Adult, exponential agreement | CDC-Diabetes, linear agreement | CDC-Diabetes, exponential agreement |
|---|---|---|---|---|
| Oracle | 1.000 [1.000, 1.000] | 1.000 [1.000, 1.000] | 1.000 [1.000, 1.000] | 1.000 [1.000, 1.000] |
| PrivAgent-6 | 0.326 [0.319, 0.332] | 0.856 [0.850, 0.862] | 0.319 [0.313, 0.326] | 0.697 [0.689, 0.704] |
| PrivAgent-6-Bayes | 0.745 [0.737, 0.753] | 0.861 [0.855, 0.867] | 0.696 [0.687, 0.704] | 0.712 [0.705, 0.719] |
| PrivAgent-LPLA | 0.175 [0.169, 0.181] | 0.880 [0.875, 0.885] | 0.170 [0.164, 0.176] | 0.711 [0.704, 0.717] |
| PrivAgent-LPLA-Bayes | 0.772 [0.765, 0.779] | 0.889 [0.884, 0.895] | 0.717 [0.711, 0.723] | 0.756 [0.748, 0.763] |
| Expert default | 0.410 [0.404, 0.417] | 0.573 [0.566, 0.580] | 0.382 [0.375, 0.388] | 0.289 [0.282, 0.296] |
| Uniform default | 0.410 [0.404, 0.417] | 0.573 [0.566, 0.580] | 0.382 [0.375, 0.388] | 0.289 [0.282, 0.296] |
| Anchored slider | 0.773 [0.766, 0.780] | 0.889 [0.885, 0.893] | 0.725 [0.720, 0.731] | 0.735 [0.730, 0.739] |

Mean closeness loss (undefined selections excluded) and share of undefined selections:

| method | Adult, linear loss | Adult, linear undefined | Adult, exponential loss | Adult, exponential undefined | CDC-Diabetes, linear loss | CDC-Diabetes, linear undefined | CDC-Diabetes, exponential loss | CDC-Diabetes, exponential undefined |
|---|---|---|---|---|---|---|---|---|
| Oracle | 0.000 [0.000, 0.000] | 0.0000 | 0.000 [0.000, 0.000] | 0.0000 | 0.000 [0.000, 0.000] | 0.0000 | 0.000 [0.000, 0.000] | 0.0000 |
| PrivAgent-6 | 0.083 [0.082, 0.085] | 0.0000 | 0.037 [0.035, 0.039] | 0.0000 | 0.087 [0.085, 0.088] | 0.0000 | 0.042 [0.040, 0.043] | 0.0000 |
| PrivAgent-6-Bayes | 0.023 [0.023, 0.024] | 0.0000 | 0.036 [0.034, 0.038] | 0.0000 | 0.023 [0.022, 0.023] | 0.0000 | 0.037 [0.035, 0.038] | 0.0000 |
| PrivAgent-LPLA | 0.088 [0.087, 0.089] | 0.0000 | 0.026 [0.024, 0.028] | 0.0000 | 0.094 [0.092, 0.095] | 0.0000 | 0.030 [0.029, 0.032] | 0.0000 |
| PrivAgent-LPLA-Bayes | 0.018 [0.017, 0.018] | 0.0000 | 0.023 [0.022, 0.025] | 0.0000 | 0.018 [0.017, 0.018] | 0.0000 | 0.025 [0.023, 0.026] | 0.0000 |
| Expert default | 0.121 [0.119, 0.123] | 0.0000 | 0.206 [0.201, 0.210] | 0.0000 | 0.103 [0.101, 0.105] | 0.0000 | 0.170 [0.167, 0.173] | 0.0000 |
| Uniform default | 0.121 [0.119, 0.123] | 0.0000 | 0.206 [0.201, 0.210] | 0.0000 | 0.103 [0.101, 0.105] | 0.0000 | 0.170 [0.167, 0.173] | 0.0000 |
| Anchored slider | 0.016 [0.016, 0.017] | 0.0000 | 0.024 [0.023, 0.025] | 0.0000 | 0.016 [0.015, 0.017] | 0.0000 | 0.028 [0.027, 0.029] | 0.0000 |

## Profile populations (Dirichlet(20 c), 5,000 users per profile)

| profile | method | cosine | share_error | agreement_adult_linear | repair_rate |
|---|---|---|---|---|---|
| Privacy-focused | Oracle | 1.000 [1.000, 1.000] | 0.000 [0.000, 0.000] | 1.000 [1.000, 1.000] | 0.0000 |
| Privacy-focused | PrivAgent-6 | 0.929 [0.927, 0.931] | 0.174 [0.171, 0.176] | 0.317 [0.306, 0.329] | 0.0024 |
| Privacy-focused | PrivAgent-6-Bayes | 0.969 [0.968, 0.971] | 0.088 [0.086, 0.090] | 0.865 [0.854, 0.875] | 0.0024 |
| Privacy-focused | PrivAgent-LPLA | 0.929 [0.927, 0.931] | 0.235 [0.232, 0.239] | 0.078 [0.070, 0.085] | 0.0000 |
| Privacy-focused | PrivAgent-LPLA-Bayes | 0.946 [0.945, 0.947] | 0.080 [0.078, 0.081] | 0.889 [0.879, 0.900] | 0.0000 |
| Privacy-focused | Expert default | 0.887 [0.885, 0.889] | 0.250 [0.247, 0.253] | 0.910 [0.900, 0.920] | 0.0000 |
| Privacy-focused | Uniform default | 0.855 [0.853, 0.857] | 0.250 [0.247, 0.253] | 0.910 [0.900, 0.919] | 0.0000 |
| Privacy-focused | Anchored slider | 0.973 [0.973, 0.974] | 0.094 [0.092, 0.096] | 0.902 [0.892, 0.911] | 0.0000 |
| Accuracy-focused | Oracle | 1.000 [1.000, 1.000] | 0.000 [0.000, 0.000] | 1.000 [1.000, 1.000] | 0.0000 |
| Accuracy-focused | PrivAgent-6 | 0.930 [0.928, 0.932] | 0.173 [0.170, 0.176] | 0.483 [0.469, 0.496] | 0.0046 |
| Accuracy-focused | PrivAgent-6-Bayes | 0.969 [0.968, 0.970] | 0.088 [0.087, 0.090] | 0.933 [0.927, 0.939] | 0.0046 |
| Accuracy-focused | PrivAgent-LPLA | 0.929 [0.927, 0.931] | 0.233 [0.230, 0.236] | 0.057 [0.050, 0.063] | 0.0000 |
| Accuracy-focused | PrivAgent-LPLA-Bayes | 0.945 [0.943, 0.947] | 0.081 [0.079, 0.083] | 0.945 [0.940, 0.950] | 0.0000 |
| Accuracy-focused | Expert default | 0.886 [0.884, 0.887] | 0.252 [0.249, 0.254] | 0.028 [0.023, 0.033] | 0.0000 |
| Accuracy-focused | Uniform default | 0.854 [0.852, 0.856] | 0.252 [0.249, 0.254] | 0.028 [0.024, 0.033] | 0.0000 |
| Accuracy-focused | Anchored slider | 0.973 [0.973, 0.974] | 0.095 [0.094, 0.097] | 0.942 [0.936, 0.948] | 0.0000 |
| Balanced | Oracle | 1.000 [1.000, 1.000] | 0.000 [0.000, 0.000] | 1.000 [1.000, 1.000] | 0.0000 |
| Balanced | PrivAgent-6 | 0.854 [0.851, 0.856] | 0.295 [0.290, 0.300] | 0.323 [0.310, 0.337] | 0.0162 |
| Balanced | PrivAgent-6-Bayes | 0.944 [0.943, 0.945] | 0.126 [0.123, 0.128] | 0.755 [0.745, 0.766] | 0.0162 |
| Balanced | PrivAgent-LPLA | 0.853 [0.850, 0.856] | 0.324 [0.319, 0.329] | 0.219 [0.209, 0.229] | 0.0000 |
| Balanced | PrivAgent-LPLA-Bayes | 0.948 [0.947, 0.950] | 0.108 [0.105, 0.111] | 0.792 [0.777, 0.807] | 0.0000 |
| Balanced | Expert default | 0.923 [0.921, 0.925] | 0.106 [0.103, 0.109] | 0.567 [0.559, 0.576] | 0.0000 |
| Balanced | Uniform default | 0.958 [0.957, 0.960] | 0.106 [0.103, 0.109] | 0.567 [0.559, 0.576] | 0.0000 |
| Balanced | Anchored slider | 0.984 [0.983, 0.984] | 0.067 [0.065, 0.068] | 0.786 [0.776, 0.798] | 0.0000 |
| Resource-constrained | Oracle | 1.000 [1.000, 1.000] | 0.000 [0.000, 0.000] | 1.000 [1.000, 1.000] | 0.0000 |
| Resource-constrained | PrivAgent-6 | 0.930 [0.928, 0.932] | 0.406 [0.401, 0.410] | 0.054 [0.047, 0.062] | 0.0030 |
| Resource-constrained | PrivAgent-6-Bayes | 0.969 [0.968, 0.970] | 0.135 [0.132, 0.138] | 0.690 [0.677, 0.702] | 0.0030 |
| Resource-constrained | PrivAgent-LPLA | 0.716 [0.713, 0.719] | 0.314 [0.310, 0.318] | 0.221 [0.211, 0.231] | 0.0000 |
| Resource-constrained | PrivAgent-LPLA-Bayes | 0.887 [0.884, 0.889] | 0.119 [0.116, 0.121] | 0.731 [0.720, 0.741] | 0.0000 |
| Resource-constrained | Expert default | 0.693 [0.690, 0.696] | 0.136 [0.132, 0.139] | 0.551 [0.532, 0.570] | 0.0000 |
| Resource-constrained | Uniform default | 0.853 [0.851, 0.855] | 0.136 [0.132, 0.139] | 0.551 [0.532, 0.569] | 0.0000 |
| Resource-constrained | Anchored slider | 0.973 [0.972, 0.973] | 0.099 [0.097, 0.102] | 0.748 [0.736, 0.759] | 0.0000 |

## Rounds analysis (PrivAgent-6, vote inference, uniform population)

| prompts | cosine | privacy_share_error | agreement_adult_linear |
|---|---|---|---|
| 1 | 0.764 [0.760, 0.768] | 0.323 [0.319, 0.326] | 0.227 [0.219, 0.234] |
| 2 | 0.847 [0.845, 0.850] | 0.262 [0.260, 0.265] | 0.216 [0.211, 0.221] |
| 3 | 0.883 [0.882, 0.885] | 0.248 [0.246, 0.250] | 0.276 [0.271, 0.281] |
| 4 | 0.905 [0.904, 0.906] | 0.230 [0.227, 0.232] | 0.309 [0.301, 0.317] |
| 5 | 0.921 [0.920, 0.922] | 0.218 [0.215, 0.220] | 0.336 [0.328, 0.344] |
| 6 | 0.930 [0.929, 0.931] | 0.212 [0.209, 0.215] | 0.326 [0.319, 0.332] |

k < 6: first k prompts, no repair; k = 6: PrivAgent-6 including the consistency check and repair. Expert default: cosine 0.803, budget agreement (Adult, linear) 0.410.

## Repair rate (PrivAgent-6)

| population | tau | repair_rate |
|---|---|---|
| accuracy_focused | 0.1 | 0.0046 |
| balanced | 0.1 | 0.0162 |
| privacy_focused | 0.1 | 0.0024 |
| resource_constrained | 0.1 | 0.0030 |
| uniform | 0.05 | 0.0009 |
| uniform | 0.1 | 0.0036 |
| uniform | 0.2 | 0.0125 |
| uniform | 0.4 | 0.0232 |

Repair is triggered when the three pair results form a cycle; every repair prompt goes to the LP-LA pair (config.yaml, prompts.repair).

## Sensitivity to the user temperature tau (uniform population)

| tau | method | cosine | share_error | agreement_adult_linear | agreement_cdc_linear | repair_rate_pa6 |
|---|---|---|---|---|---|---|
| 0.05 | PrivAgent-6 | 0.944 [0.943, 0.945] | 0.194 [0.191, 0.197] | 0.331 [0.324, 0.337] | 0.328 [0.321, 0.336] | 0.0009 |
| 0.05 | PrivAgent-6-Bayes | 0.972 [0.972, 0.973] | 0.106 [0.105, 0.108] | 0.798 [0.791, 0.805] | 0.750 [0.743, 0.757] | 0.0009 |
| 0.05 | PrivAgent-LPLA | 0.841 [0.839, 0.843] | 0.231 [0.229, 0.233] | 0.128 [0.122, 0.133] | 0.123 [0.117, 0.128] | 0.0009 |
| 0.05 | PrivAgent-LPLA-Bayes | 0.908 [0.907, 0.910] | 0.102 [0.101, 0.103] | 0.818 [0.812, 0.824] | 0.762 [0.757, 0.768] | 0.0009 |
| 0.1 | PrivAgent-6 | 0.930 [0.929, 0.931] | 0.212 [0.209, 0.215] | 0.326 [0.319, 0.332] | 0.319 [0.313, 0.326] | 0.0036 |
| 0.1 | PrivAgent-6-Bayes | 0.961 [0.961, 0.962] | 0.126 [0.124, 0.127] | 0.745 [0.737, 0.753] | 0.696 [0.687, 0.704] | 0.0036 |
| 0.1 | PrivAgent-LPLA | 0.850 [0.848, 0.852] | 0.228 [0.226, 0.230] | 0.175 [0.169, 0.181] | 0.170 [0.164, 0.176] | 0.0036 |
| 0.1 | PrivAgent-LPLA-Bayes | 0.908 [0.907, 0.909] | 0.113 [0.112, 0.115] | 0.772 [0.765, 0.779] | 0.717 [0.711, 0.723] | 0.0036 |
| 0.2 | PrivAgent-6 | 0.887 [0.885, 0.888] | 0.246 [0.243, 0.248] | 0.335 [0.328, 0.342] | 0.323 [0.315, 0.331] | 0.0125 |
| 0.2 | PrivAgent-6-Bayes | 0.925 [0.924, 0.926] | 0.166 [0.165, 0.168] | 0.667 [0.659, 0.676] | 0.616 [0.606, 0.625] | 0.0125 |
| 0.2 | PrivAgent-LPLA | 0.840 [0.838, 0.842] | 0.245 [0.242, 0.247] | 0.225 [0.219, 0.231] | 0.215 [0.209, 0.221] | 0.0125 |
| 0.2 | PrivAgent-LPLA-Bayes | 0.886 [0.885, 0.888] | 0.154 [0.152, 0.156] | 0.692 [0.684, 0.701] | 0.639 [0.632, 0.647] | 0.0125 |
| 0.4 | PrivAgent-6 | 0.814 [0.812, 0.816] | 0.296 [0.293, 0.298] | 0.315 [0.310, 0.321] | 0.297 [0.291, 0.303] | 0.0232 |
| 0.4 | PrivAgent-6-Bayes | 0.871 [0.869, 0.872] | 0.212 [0.210, 0.214] | 0.576 [0.567, 0.585] | 0.527 [0.518, 0.536] | 0.0232 |
| 0.4 | PrivAgent-LPLA | 0.802 [0.799, 0.804] | 0.291 [0.287, 0.295] | 0.247 [0.239, 0.255] | 0.233 [0.224, 0.240] | 0.0232 |
| 0.4 | PrivAgent-LPLA-Bayes | 0.853 [0.852, 0.855] | 0.202 [0.199, 0.204] | 0.597 [0.588, 0.606] | 0.550 [0.542, 0.558] | 0.0232 |

The analyst's tau of the Bayesian inference stays 0.1 for every user tau. Answers are coupled across tau (the same uniform draws).

## Sensitivity to the anchoring strength lambda (anchored slider, uniform population)

| lam | cosine | share_error | agreement_adult_linear | agreement_cdc_linear |
|---|---|---|---|---|
| 0 | 0.982 [0.982, 0.982] | 0.102 [0.101, 0.103] | 0.691 [0.683, 0.698] | 0.661 [0.652, 0.669] |
| 0.2 | 0.981 [0.981, 0.982] | 0.097 [0.096, 0.098] | 0.758 [0.751, 0.766] | 0.726 [0.718, 0.733] |
| 0.4 | 0.972 [0.972, 0.972] | 0.116 [0.115, 0.117] | 0.773 [0.766, 0.780] | 0.725 [0.720, 0.731] |
| 0.6 | 0.947 [0.946, 0.947] | 0.156 [0.155, 0.158] | 0.764 [0.757, 0.771] | 0.709 [0.704, 0.716] |

PrivAgent-6 for reference: cosine 0.930 [0.929, 0.931], share error 0.212 [0.209, 0.215], agreement Adult 0.326 [0.319, 0.332], CDC-Diabetes 0.319 [0.313, 0.326].

## Runtime

python -m src.run: 92.8 s wall clock (20 replications, 720000 user-method rows, 2880000 decisions)


## Notes on the specification (fixed before the main run)

- Switch points of Chapter 6: on a grid of step 0.001 of the privacy share (w_CR = 0), the first grid value at which Adult/linear selects a new budget is 0.013, 0.472, 0.887 and 0.946, as in Chapter 6; the exact switch points are 0.0123, 0.4719, 0.8863 and 0.9455.
- Repair: a cycle requires all three pairs to be decided, so no pair is split when a cycle is detected; the repair prompt goes to the first pair in the stated order (LP-LA).
- The Bayesian unit test uses 200 answers drawn from exactly the analyst's response model (tau = 0.1); deterministic answers to the fixed templates reveal only the ranking of the weights.
- Bayesian inference: one set of 20,000 prior draws per replication and prompt set (fixed stream), shared by the users of that replication.

## Deviations

None. No file committed at pre-registration (config.yaml, hypotheses.md, src/, tests/) was changed after the commit.
